const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('نیا صارف منسلک ہوا');

  socket.on('new-user', (username) => {
    socket.username = username;
    socket.broadcast.emit('message', `${username} چیٹ میں شامل ہوا`);
  });

  socket.on('sendMessage', (msg) => {
    const time = new Date().toLocaleTimeString();
    io.emit('message', `${socket.username} (${time}): ${msg}`);
  });

  socket.on('disconnect', () => {
    if (socket.username) {
      io.emit('message', `${socket.username} چیٹ سے نکل گیا`);
    }
  });
});

http.listen(3000, () => {
  console.log('سرور چل رہا ہے: http://localhost:3000');
});
